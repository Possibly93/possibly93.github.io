A Pen created at CodePen.io. You can find this one at http://codepen.io/jkantner/pen/jAzyEv.

 A CSS-animated journey through a maze based on a screensaver from Windows 95 and 98. The turning at corners or dead ends can sometimes be shaky because of how transform-origin needs to be adjusted to keep up with the camera position.